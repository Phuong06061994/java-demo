export const environment = {
  production: true,
  apiPath: ''
};
